from django.contrib import messages, auth
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from cab.forms import RegisterForm, CabForm
from cab.models import Booking, Cab


# Create your views here.

def home(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return redirect('admin_home')
        else:
            return redirect('user_home')

    return render(request, 'home.html')


def home_redirect(request):
    if not request.user.is_authenticated:
        return redirect('home')
    if request.user.is_superuser:
        return redirect('admin_home')
    else:
        return redirect('user_home')


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            messages.success(request, "Registration successful")
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, 'register.html', {'form': form})


def user_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, email=email, password=password)

        if user is not None:
            login(request, user)
            if user.is_superuser:
                return redirect('admin_home')
            else:
                return redirect('user_home')
        else:
            messages.error(request, "Invalid email or password")
    return render(request, 'login.html')


@login_required()
def logout(request):
    auth.logout(request)
    return redirect('home')


@login_required()
def add_cab(request):
    if not request.user.is_staff:
        return redirect('user_home')

    if request.method == 'POST':
        form = CabForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('cab_list')
    else:
        form = CabForm()

    return render(request, 'add_cab.html', {'form': form})


@login_required()
def available_cabs(request):
    cabs = Cab.objects.filter(is_available=True)
    return render(request, 'available_cabs.html', {'cabs': cabs})


@login_required()
def book_cab(request, cab_id):
    cab = get_object_or_404(Cab, id=cab_id, is_available=True)

    # check if user already booked
    if Booking.objects.filter(user=request.user, is_active=True).exists():
        messages.error(request, "You already have an active booking")
        return redirect('available_cabs')

    Booking.objects.create(user=request.user, cab=cab)
    cab.is_available = False
    cab.save()

    messages.success(request, "Cab booked successfully")
    return redirect('user_home')


@login_required()
def all_bookings(request):
    if not request.user.is_staff:
        return redirect('user_home')

    bookings = Booking.objects.filter(is_active=True)
    return render(request, 'all_bookings.html', {'bookings': bookings})


@login_required()
def end_booking(request, booking_id):
    if not request.user.is_staff:
        return redirect('user_home  ')

    booking = get_object_or_404(Booking, id=booking_id)
    booking.is_active = False
    booking.cab.is_available = True

    booking.cab.save()
    booking.save()

    return redirect('all_bookings')


def admin_home(request):
    cabs = Cab.objects.count()
    book = Booking.objects.count()
    return render(request, 'admin_home.html', {'cabs': cabs, 'book': book})


def user_home(request):
    active_booking = Booking.objects.filter(
        user=request.user,
        is_active=True
    ).first()
    return render(request, 'user_home.html', {'active_booking': active_booking})


def cab_list(request):
    cl = Cab.objects.all()
    return render(request, 'cab_list.html', {'cl': cl})


def edit_cab(request, cab_id):
    ct = get_object_or_404(Cab, id=cab_id)
    if request.method == 'POST':
        form = CabForm(request.POST, instance=ct)
        if form.is_valid():
            form.save()
            return redirect('cab_list')
    else:
        form = CabForm(instance=ct)
    return render(request, 'edit_cab.html', {
        'form': form,
        'ct': ct
    })


def delete_cab(request, cab_id):
    if not request.user.is_superuser:
        return redirect('admin_home')

    ct = get_object_or_404(Cab, id=cab_id)
    ct.delete()
    return redirect('cab_list')


@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(
        Booking,
        id=booking_id,
        user=request.user,
        is_active=True
    )
    cab = booking.cab
    cab.is_available = True
    cab.save()
    booking.is_active = False
    booking.save()

    return redirect('user_home')


def my_bookings(request):
    boo = Booking.objects.filter(user=request.user)
    return render(request, 'my_bookings.html', {'boo': boo})

