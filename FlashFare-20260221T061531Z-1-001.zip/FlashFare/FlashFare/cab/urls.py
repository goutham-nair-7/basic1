from django.urls import path
from . import views
import cab

urlpatterns = [
    path('', cab.views.home, name='home'),
    path('home_redirect', cab.views.home_redirect, name='home_redirect'),
    path('register', cab.views.register, name='register'),
    path('user_login', cab.views.user_login, name='login'),
    path('logout', cab.views.logout, name='logout'),
    path('add_cab', cab.views.add_cab, name='add_cab'),
    path('available_cabs', cab.views.available_cabs, name='available_cabs'),
    path('book_cab/<int:cab_id>/', cab.views.book_cab, name='book_cab'),
    path('all_bookings', cab.views.all_bookings, name='all_bookings'),
    path('end_booking/<int:booking_id>/', cab.views.end_booking, name='end_booking'),
    path('admin_home', cab.views.admin_home, name='admin_home'),
    path('user_home', cab.views.user_home, name='user_home'),
    path('cab_list', cab.views.cab_list, name='cab_list'),
    path('edit_cab/<int:cab_id>/', cab.views.edit_cab, name='edit_cab'),
    path('delete_cab/<int:cab_id>/', cab.views.delete_cab, name='delete_cab'),
    path('cancel_booking/<int:booking_id>/', cab.views.cancel_booking, name='cancel_booking'),
    path('my_bookings', cab.views.my_bookings, name='my_bookings'),
]