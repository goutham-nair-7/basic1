from django import forms

from cab.models import Cab, User, Booking


class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['full_name', 'email', 'phone_number', 'password']

    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get('password') != cleaned_data.get('confirm_password'):
            raise forms.ValidationError("Passwords do not match")


class CabForm(forms.ModelForm):
    class Meta:
        model = Cab
        fields = ['cab_number', 'cab_type', 'driver_name']
        widgets = {
            'cab_number': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Cab Number'
            }),
            'cab_type': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Cab Type (Sedan, SUV...)'
            }),
            'driver_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Driver Name'
            }),
        }


class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = []
